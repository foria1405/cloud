<?php echo $header; ?>

<section class="content">
  <article>
    <h1>Anchor is already installed</h1>

      <?php echo Notify::read(); ?>
  </article>
</section>

<?php echo $footer; ?>
