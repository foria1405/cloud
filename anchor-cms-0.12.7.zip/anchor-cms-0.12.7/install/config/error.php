<?php

return [
    'report' => true,
    'logger' => function ($exception) {
    }
];
