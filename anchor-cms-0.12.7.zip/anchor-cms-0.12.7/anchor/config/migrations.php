<?php

return [
    /*
     * Latest migration
     * override for testing/development
     */
    'current' => MIGRATION_NUMBER
];
