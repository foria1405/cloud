<?php

return [

    'menu'      => 'Menu',
    'edit_menu' => 'Edit menu'

];
