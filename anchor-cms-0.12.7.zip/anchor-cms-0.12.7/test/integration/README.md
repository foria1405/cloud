Integration tests (JavaScript)
==============================

This directory contains the Integration tests using Puppeteer and Jest. This isn't about testing the 
JavaScript side of things, however, but rather the complete user interaction with AnchorCMS.  
Using Puppeteer, we can spin up a fully fledged headless version of Google Chrome that will carry out
anything we command it to.
