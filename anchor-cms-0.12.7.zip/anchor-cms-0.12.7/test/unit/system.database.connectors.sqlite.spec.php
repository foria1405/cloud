<?php

xdescribe('database\\connectors\\sqlite (TODO: Write tests)', function () {

});
