<?php

/**
 * Nano
 * Just another php framework
 *
 * @package    nano
 * @link       http://madebykieron.co.uk
 * @copyright  http://unlicense.org/
 */

use System\config;
use System\uri;

/**
 * Get a relative uri to be used with a view
 *
 * @example asset('styles.css');
 *
 * @param string $uri asset URI
 *
 * @return string resolved asset URI
 */
function asset($uri)
{
    return rtrim(Config::app('url'), '/') . '/' . $uri;
}

/**
 * Alias to class uri to method
 *
 * @param string $uri destination URI to resolve
 *
 * @return string resolved destination URI
 */
function uri_to($uri)
{
    return Uri::to($uri);
}

/**
 * Debugging function, simply a var_dump wrapper
 *
 * @example dd($something, $another);
 *
 * @param mixed[] ...,
 */
function dd()
{
    echo '<pre>';
    call_user_func_array('var_dump', func_get_args());
    echo '</pre>';
    exit;
}

/**
 * Generates a random string
 *
 * @param int $size (optional) desired random string length
 *
 * @return string random string
 */
function noise($size = 32)
{
    $pool = 'abcefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';

    $factory = new RandomLib\Factory();

    $generator = $factory->getMediumStrengthGenerator();

    return $generator->generateString($size, $pool);
}

/**
 * Normalise a string replacing foreign characters
 *
 * @param string $str string to normalise
 *
 * @return string normalised string
 */
function normalize($str)
{
    // @formatter:off
    $a = array('À', 'Á', 'Â', 'Ã', 'Ä', 'Å', 'Æ', 'Ç', 'È', 'É', 'Ê', 'Ë', 'Ì', 'Í', 'Î', 'Ï', 'Ð', 'Ñ', 'Ò', 'Ó', 'Ô', 'Õ', 'Ö', 'Ø', 'Ù', 'Ú', 'Û', 'Ü', 'Ý', 'ß', 'à', 'á', 'â', 'ã', 'ä', 'å', 'æ', 'ç', 'è', 'é', 'ê', 'ë', 'ì', 'í', 'î', 'ï', 'ñ', 'ò', 'ó', 'ô', 'õ', 'ö', 'ø', 'ù', 'ú', 'û', 'ü', 'ý', 'ÿ', 'Ā', 'ā', 'Ă', 'ă', 'Ą', 'ą', 'Ć', 'ć', 'Ĉ', 'ĉ', 'Ċ', 'ċ', 'Č', 'č', 'Ď', 'ď', 'Đ', 'đ', 'Ē', 'ē', 'Ĕ', 'ĕ', 'Ė', 'ė', 'Ę', 'ę', 'Ě', 'ě', 'Ĝ', 'ĝ', 'Ğ', 'ğ', 'Ġ', 'ġ', 'Ģ', 'ģ', 'Ĥ', 'ĥ', 'Ħ', 'ħ', 'Ĩ', 'ĩ', 'Ī', 'ī', 'Ĭ', 'ĭ', 'Į', 'į', 'İ', 'ı', 'Ĳ', 'ĳ', 'Ĵ', 'ĵ', 'Ķ', 'ķ', 'Ĺ', 'ĺ', 'Ļ', 'ļ', 'Ľ', 'ľ', 'Ŀ', 'ŀ', 'Ł', 'ł', 'Ń', 'ń', 'Ņ', 'ņ', 'Ň', 'ň', 'ŉ', 'Ō', 'ō', 'Ŏ', 'ŏ', 'Ő', 'ő', 'Œ', 'œ', 'Ŕ', 'ŕ', 'Ŗ', 'ŗ', 'Ř', 'ř', 'Ś', 'ś', 'Ŝ', 'ŝ', 'Ş', 'ş', 'Š', 'š', 'Ţ', 'ţ', 'Ť', 'ť', 'Ŧ', 'ŧ', 'Ũ', 'ũ', 'Ū', 'ū', 'Ŭ', 'ŭ', 'Ů', 'ů', 'Ű', 'ű', 'Ų', 'ų', 'Ŵ', 'ŵ', 'Ŷ', 'ŷ', 'Ÿ', 'Ź', 'ź', 'Ż', 'ż', 'Ž', 'ž', 'ſ', 'ƒ', 'Ơ', 'ơ', 'Ư', 'ư', 'Ǎ', 'ǎ', 'Ǐ', 'ǐ', 'Ǒ', 'ǒ', 'Ǔ', 'ǔ', 'Ǖ', 'ǖ', 'Ǘ', 'ǘ', 'Ǚ', 'ǚ', 'Ǜ', 'ǜ', 'Ǻ', 'ǻ', 'Ǽ', 'ǽ', 'Ǿ', 'ǿ');

    $b = array('A', 'A', 'A', 'A', 'A', 'A', 'AE', 'C', 'E', 'E', 'E', 'E', 'I', 'I', 'I', 'I', 'D', 'N', 'O', 'O', 'O', 'O', 'O', 'O', 'U', 'U', 'U', 'U', 'Y', 's', 'a', 'a', 'a', 'a', 'a', 'a', 'ae', 'c', 'e', 'e', 'e', 'e', 'i', 'i', 'i', 'i', 'n', 'o', 'o', 'o', 'o', 'o', 'o', 'u', 'u', 'u', 'u', 'y', 'y', 'A', 'a', 'A', 'a', 'A', 'a', 'C', 'c', 'C', 'c', 'C', 'c', 'C', 'c', 'D', 'd', 'D', 'd', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'G', 'g', 'G', 'g', 'G', 'g', 'G', 'g', 'H', 'h', 'H', 'h', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'IJ', 'ij', 'J', 'j', 'K', 'k', 'L', 'l', 'L', 'l', 'L', 'l', 'L', 'l', 'l', 'l', 'N', 'n', 'N', 'n', 'N', 'n', 'n', 'O', 'o', 'O', 'o', 'O', 'o', 'OE', 'oe', 'R', 'r', 'R', 'r', 'R', 'r', 'S', 's', 'S', 's', 'S', 's', 'S', 's', 'T', 't', 'T', 't', 'T', 't', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'W', 'w', 'Y', 'y', 'Y', 'Z', 'z', 'Z', 'z', 'Z', 'z', 's', 'f', 'O', 'o', 'U', 'u', 'A', 'a', 'I', 'i', 'O', 'o', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'A', 'a', 'AE', 'ae', 'O', 'o');
    // @formatter:on

    return str_replace($a, $b, $str);
}

/**
 * Encode html to entities
 *
 * @param string|string[] $str    string or array of strings to encode HTML in
 * @param int             $quotes (optional) whether to encode quotes.
 *
 * @return string|string[] encoded string or strings
 */
function e($str, $quotes = ENT_NOQUOTES)
{
    if (is_array($str)) {
        $arr = [];

        foreach ($str as $key => $value) {
            if ( ! is_array($value)) {
                $arr += [$key => e($value)];
            } else {
                $arr[$key] = e($value);
            }
        }

        return $arr;
    }

    /** @noinspection PhpUndefinedMethodInspection */
    return htmlspecialchars($str, $quotes, Config::app('encoding'), false);
}

/**
 * Alias for e($str, ENT_QUOTES)
 *
 * @param string|string[] $str string or array of strings to encode HTML in
 *
 * @return string|string[] string or strings
 */
function eq($str)
{
    return e($str, ENT_QUOTES);
}

/**
 * Flatten an array
 *
 * @param array[] $array  array of arrays to flatted
 * @param array   $return array to flatten to
 *
 * @return array flattened array
 */
function array_flatten($array, $return)
{
    foreach ($array as $item) {
        if (is_array($item)) {
            $return = array_flatten($item, $return);
        } else {
            if (isset($item)) {
                $return[] = $item;
            }
        }
    }

    return $return;
}
